module Sprockets
  module Helpers
    autoload :RailsHelper,    "sprockets/helpers/rails_helper"
    autoload :IsolatedHelper, "sprockets/helpers/isolated_helper"
  end
end
