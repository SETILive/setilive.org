module Something
  class Thingy
    def do_something
      # ...
    end
  end
end
