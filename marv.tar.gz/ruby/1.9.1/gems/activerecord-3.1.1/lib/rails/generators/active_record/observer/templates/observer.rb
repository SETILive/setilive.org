<% module_namespacing do -%>
class <%= class_name %>Observer < ActiveRecord::Observer
end
<% end -%>
