module BadgesHelper
end
