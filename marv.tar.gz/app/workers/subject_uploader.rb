class SubjectUploader
  include Sidekiq::Worker 

  def perform(subject)

    
  end
end