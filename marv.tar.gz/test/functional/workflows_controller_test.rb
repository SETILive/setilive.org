require 'test_helper'

class WorkflowsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
