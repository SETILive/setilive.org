require 'test_helper'

class ZooniverseUsersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
