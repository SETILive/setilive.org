require 'test_helper'

class BadgesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
