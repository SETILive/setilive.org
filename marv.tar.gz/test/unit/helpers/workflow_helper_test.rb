require 'test_helper'

class WorkflowHelperTest < ActionView::TestCase
end
