require 'test_helper'

class FavouritesHelperTest < ActionView::TestCase
end
