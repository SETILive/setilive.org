require 'test_helper'

class ZooniverseUsersHelperTest < ActionView::TestCase
end
