require 'test_helper'

class ClassificationsHelperTest < ActionView::TestCase
end
