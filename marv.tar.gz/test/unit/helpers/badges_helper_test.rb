require 'test_helper'

class BadgesHelperTest < ActionView::TestCase
end
