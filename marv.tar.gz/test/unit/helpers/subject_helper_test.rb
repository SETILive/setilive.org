require 'test_helper'

class SubjectHelperTest < ActionView::TestCase
end
