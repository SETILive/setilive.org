require 'test_helper'

class AccountsHelperTest < ActionView::TestCase
end
