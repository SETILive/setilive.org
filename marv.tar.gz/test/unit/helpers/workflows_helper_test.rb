require 'test_helper'

class WorkflowsHelperTest < ActionView::TestCase
end
