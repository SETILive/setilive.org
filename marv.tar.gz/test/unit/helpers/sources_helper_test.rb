require 'test_helper'

class SourcesHelperTest < ActionView::TestCase
end
