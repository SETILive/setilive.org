require 'test_helper'

class SubjectSignalsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
