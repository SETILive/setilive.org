require 'test_helper'

class ZooniverseUserExtraInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
