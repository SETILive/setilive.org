# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Marv::Application.config.secret_token = '357e4fdee12ed6d5e16fb7ac94830d32414f62879d626bb4960c5c5afe0fd15a24f3e16a736c08892fbdf93316fc973ea7e652b35e1bdbe2379681b54b32129e'
